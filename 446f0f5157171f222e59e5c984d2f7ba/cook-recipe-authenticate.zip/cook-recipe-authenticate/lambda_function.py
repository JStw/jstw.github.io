import json
import requests
import urllib3

token_url = "https://<< your domain name >>.auth.<< your AWS region 
>>.amazoncognito.com/oauth2/token"
callback_uri = "https://www.google.com/authenticate"
client_id = '<< your app client id >>'
client_secret = '<< your app client secret >>'

def lambda_handler(event, context):
    authorization_code = event['pathParameters']['code']
    data = {'grant_type': 'authorization_code', 'code': 
authorization_code, 'redirect_uri': callback_uri}
    access_token_response = requests.post(token_url, data=data, 
verify=True, allow_redirects=False, auth=(client_id, client_secret))
    
    return json.loads(access_token_response.text)
